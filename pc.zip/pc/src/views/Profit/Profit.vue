<template>
    <div>
        <div class="banner_img" style="align-items: center;">
            <img
                src="http://www.igeqin.com/App/Tpl/Home/Defaults/Public/images/images2/banner_05.jpg"
                style="width: 100%;"
            />
        </div>
        <div class="banner_img" style="align-items: center;">
            <img
                src="http://www.igeqin.com/App/Tpl/Home/Defaults/Public/images/images2/part_1.jpg"
                style="width: 100%;"
            />
        </div>
        <div class="banner_img" style="align-items: center;">
            <img
                src="http://www.igeqin.com/App/Tpl/Home/Defaults/Public/images/images2/part_2.jpg"
                style="width: 100%;"
            />
        </div>
        <div class="banner_img" style="align-items: center;">
            <img
                src="http://www.igeqin.com/App/Tpl/Home/Defaults/Public/images/images2/part_3.jpg"
                style="width: 100%;"
            />
        </div>
        <div class="banner_img" style="align-items: center;">
            <img
                src="http://www.igeqin.com/App/Tpl/Home/Defaults/Public/images/images2/part_4.jpg"
                style="width: 100%;"
            />
        </div>
        <div class="banner_img" style="align-items: center;">
            <img
                src="http://www.igeqin.com/App/Tpl/Home/Defaults/Public/images/images2/part_5.jpg"
                style="width: 100%;"
            />
        </div>
        <div class="banner_img" style="align-items: center;">
            <img
                src="http://www.igeqin.com/App/Tpl/Home/Defaults/Public/images/images2/part_6.jpg"
                style="width: 100%;"
            />
        </div>
    </div>
</template>
<script>
export default {};
</script>
<style lang="less" scoped>
.banner_img {
    width: 100%;
    overflow: hidden;
    img {
        display: block;
        margin: 0px auto;
    }
}
</style>
